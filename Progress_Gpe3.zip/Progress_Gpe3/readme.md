Ce petit document vous Présente en gros de quoi il est question.

 //''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
 
 Il s'agit d'un devoir de groupe de 5 personnes, ici le groupe 3
 De la première promotion de Inclassé PowerEdge by Simplon.

 Nous devons imiter un site vitrine suivant le modelé fourni par le
 Formateur. Vous trouverez ce modèle joint dans le dossier "Brief Projet" 

 //''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

Le projet en question contient 5 pages HTML et un seul Fichier CSS
Ainsi qu’un dossier image ou sont regroupés toutes les images utiles à la
Réalisation du site.

//''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

Nous avons commencé par travailler l'entête le premier jour et chacun a
Récupérer le travail du groupe pour insérer la corp de la page qui lui a 
Été confiée.

//''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

Nous vous prions de bien vouloir nous retourner vous appréciations et 
Critiques afin que nous améliorions notre travaille.
